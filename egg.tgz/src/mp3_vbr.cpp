// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode VBR stream\n", stdout);
  return lionss_run_workload("mp3_vbr");
}
