// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Replay recorded trace"); }
int main(){
  announce();
  return lionss_run_workload("recordReplay");
}
