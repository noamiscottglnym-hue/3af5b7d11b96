// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate brightwater flow\n", stdout);
  return lionss_run_workload("brightwater-7");
}
